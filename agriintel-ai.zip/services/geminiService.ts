
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { SYSTEM_INSTRUCTIONS } from "../constants";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  }

  async queryAgriculturalExpert(prompt: string, imageBase64?: string, useSearch: boolean = false) {
    const contents: any[] = [];
    
    if (imageBase64) {
      contents.push({
        inlineData: {
          mimeType: 'image/jpeg',
          data: imageBase64.split(',')[1] || imageBase64
        }
      });
    }

    contents.push({ text: prompt });

    const config: any = {
      systemInstruction: SYSTEM_INSTRUCTIONS,
    };

    if (useSearch) {
      config.tools = [{ googleSearch: {} }];
    }

    const response: GenerateContentResponse = await this.ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: { parts: contents },
      config
    });

    return {
      text: response.text || "I couldn't generate a response. Please try again.",
      groundingChunks: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  }

  async *streamAgriculturalExpert(prompt: string) {
    const responseStream = await this.ai.models.generateContentStream({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTIONS,
        tools: [{ googleSearch: {} }]
      }
    });

    for await (const chunk of responseStream) {
      yield {
        text: chunk.text,
        groundingChunks: chunk.candidates?.[0]?.groundingMetadata?.groundingChunks || []
      };
    }
  }
}

export const geminiService = new GeminiService();
