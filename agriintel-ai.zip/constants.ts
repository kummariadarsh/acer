
import { MarketData } from './types';

export const SYSTEM_INSTRUCTIONS = `You are AgriIntel AI, a world-class agricultural expert. 
Your goal is to provide accurate, science-based advice to farmers and agricultural professionals.
You specialize in:
1. Crop management and optimization.
2. Pest and disease identification and integrated pest management (IPM).
3. Soil health and fertilization strategies.
4. Sustainable farming practices.
5. Market trend analysis.

When asked about market prices or weather, always use the Google Search tool.
Provide clear, actionable, and structured advice. Use Markdown for formatting.`;

export const MOCK_MARKET_DATA: MarketData[] = [
  { crop: 'Wheat', price: 215.50, change: +2.4, trend: 'up' },
  { crop: 'Corn', price: 185.20, change: -1.2, trend: 'down' },
  { crop: 'Soybeans', price: 440.00, change: +0.5, trend: 'up' },
  { crop: 'Rice', price: 16.80, change: 0, trend: 'stable' },
  { crop: 'Coffee', price: 198.40, change: +5.2, trend: 'up' },
];
