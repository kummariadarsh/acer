
import React, { useState, useRef, useEffect } from 'react';
import { Send, User, Bot, Loader2, Search, ExternalLink } from 'lucide-react';
import { Message } from '../types';
import { geminiService } from '../services/geminiService';

const ChatInterface: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    { 
      role: 'model', 
      content: 'Hello! I am your AI agricultural expert. How can I help you today? You can ask me about crop cycles, irrigation, pest control, or current market trends.' 
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMsg: Message = { role: 'user', content: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      // For general chat, we use streaming for better UX
      const stream = geminiService.streamAgriculturalExpert(input);
      let fullContent = '';
      let urls: Array<{title: string, uri: string}> = [];

      setMessages(prev => [...prev, { role: 'model', content: '', isStreaming: true }]);

      for await (const chunk of stream) {
        fullContent += chunk.text;
        if (chunk.groundingChunks) {
          chunk.groundingChunks.forEach((c: any) => {
            if (c.web) {
              urls.push({ title: c.web.title, uri: c.web.uri });
            }
          });
        }
        
        setMessages(prev => {
          const last = prev[prev.length - 1];
          const rest = prev.slice(0, -1);
          return [...rest, { ...last, content: fullContent, groundingUrls: urls }];
        });
      }

      setMessages(prev => {
        const last = prev[prev.length - 1];
        const rest = prev.slice(0, -1);
        return [...rest, { ...last, isStreaming: false }];
      });
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, { role: 'model', content: "I'm sorry, I encountered an error. Please check your connectivity and try again." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full max-w-4xl mx-auto">
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto space-y-6 pb-24 pr-2"
      >
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 shadow-sm ${
              msg.role === 'user' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600 border border-slate-200'
            }`}>
              {msg.role === 'user' ? <User size={18} /> : <Bot size={18} />}
            </div>
            
            <div className={`flex flex-col max-w-[85%] ${msg.role === 'user' ? 'items-end' : ''}`}>
              <div className={`px-4 py-3 rounded-2xl whitespace-pre-wrap ${
                msg.role === 'user' 
                  ? 'bg-emerald-600 text-white rounded-tr-none' 
                  : 'bg-slate-50 text-slate-700 border border-slate-100 rounded-tl-none'
              }`}>
                {msg.content}
                {msg.isStreaming && <span className="inline-block w-1.5 h-4 ml-1 bg-emerald-400 animate-pulse align-middle" />}
              </div>

              {msg.groundingUrls && msg.groundingUrls.length > 0 && (
                <div className="mt-3 flex flex-wrap gap-2">
                  <span className="text-[10px] uppercase tracking-wider font-bold text-slate-400 w-full mb-1">Sources</span>
                  {msg.groundingUrls.map((link, i) => (
                    <a 
                      key={i} 
                      href={link.uri} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 px-2 py-1 bg-slate-100 hover:bg-slate-200 rounded text-xs text-slate-600 transition-colors"
                    >
                      <Search size={10} />
                      <span className="truncate max-w-[120px]">{link.title}</span>
                      <ExternalLink size={10} />
                    </a>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
        {isLoading && !messages[messages.length - 1].isStreaming && (
          <div className="flex gap-4">
            <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center shrink-0 border border-slate-200">
              <Bot size={18} className="text-slate-400" />
            </div>
            <div className="bg-slate-50 border border-slate-100 px-4 py-3 rounded-2xl rounded-tl-none">
              <Loader2 className="w-5 h-5 animate-spin text-emerald-600" />
            </div>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="fixed bottom-6 left-6 right-6 lg:left-80 lg:right-12 z-10">
        <form 
          onSubmit={handleSubmit}
          className="max-w-4xl mx-auto bg-white rounded-2xl shadow-xl shadow-slate-200/60 border border-slate-100 p-2 flex items-center gap-2"
        >
          <input 
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask anything about your crops..."
            className="flex-1 px-4 py-3 text-slate-700 placeholder:text-slate-400 focus:outline-none bg-transparent"
          />
          <button 
            type="submit"
            disabled={isLoading || !input.trim()}
            className="p-3 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-200 text-white rounded-xl transition-all shadow-md active:scale-95"
          >
            {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
          </button>
        </form>
      </div>
    </div>
  );
};

export default ChatInterface;
