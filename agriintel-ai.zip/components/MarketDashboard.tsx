
import React, { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight, RefreshCw, Info } from 'lucide-react';
import { MOCK_MARKET_DATA } from '../constants';

const MarketDashboard: React.FC = () => {
  const [data, setData] = useState(MOCK_MARKET_DATA);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const refreshData = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setData(prev => prev.map(item => ({
        ...item,
        price: item.price + (Math.random() * 4 - 2),
        change: Math.random() * 2 - 1
      })));
      setIsRefreshing(false);
    }, 1000);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-2xl font-bold text-slate-800">Global Agri Markets</h3>
          <p className="text-slate-500">Live commodity prices and seasonal trend forecasts.</p>
        </div>
        <button 
          onClick={refreshData}
          disabled={isRefreshing}
          className="flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl font-medium transition-all"
        >
          <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          Refresh
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {data.slice(0, 4).map((item, idx) => (
          <div key={idx} className="bg-white p-5 rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex justify-between items-start mb-4">
              <span className="text-sm font-semibold text-slate-400 uppercase tracking-wider">{item.crop}</span>
              <div className={`p-1 rounded ${item.change >= 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
                {item.change >= 0 ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
              </div>
            </div>
            <div className="flex items-end gap-2">
              <span className="text-2xl font-bold text-slate-800">${item.price.toFixed(2)}</span>
              <span className={`text-xs font-bold mb-1.5 ${item.change >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                {item.change >= 0 ? '+' : ''}{item.change.toFixed(2)}%
              </span>
            </div>
            <div className="mt-4 h-12">
               <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={[...Array(7)].map((_, i) => ({ val: item.price + Math.random() * 10 }))}>
                    <Area type="monotone" dataKey="val" stroke={item.change >= 0 ? '#10b981' : '#f43f5e'} fill={item.change >= 0 ? '#10b98110' : '#f43f5e10'} />
                  </AreaChart>
               </ResponsiveContainer>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
          <h4 className="font-bold text-slate-800 mb-6">Price Comparison (per metric ton)</h4>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="crop" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <Tooltip 
                  cursor={{fill: '#f8fafc'}}
                  contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}}
                />
                <Bar dataKey="price" fill="#10b981" radius={[8, 8, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-emerald-900 rounded-3xl p-6 text-white flex flex-col justify-between overflow-hidden relative">
          <div className="relative z-10">
            <div className="p-3 bg-emerald-500/20 w-fit rounded-2xl mb-4 border border-emerald-500/30">
              <Info className="w-6 h-6 text-emerald-400" />
            </div>
            <h4 className="text-xl font-bold mb-2">Market Insight</h4>
            <p className="text-emerald-100/80 text-sm leading-relaxed">
              Wheat prices are currently surging due to a projected 15% shortfall in spring harvests across the Northern Hemisphere. 
              <br/><br/>
              <b>AgriIntel Strategy:</b> Consider allocating additional storage space for your grain to capitalize on projected peak prices in Q4.
            </p>
          </div>
          <button className="mt-8 py-3 bg-white text-emerald-900 rounded-xl font-bold text-sm hover:bg-emerald-50 transition-colors relative z-10">
            Full Market Analysis
          </button>
          
          {/* Decorative shapes */}
          <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-emerald-500/10 rounded-full blur-3xl" />
          <div className="absolute -top-10 -left-10 w-32 h-32 bg-emerald-300/10 rounded-full blur-2xl" />
        </div>
      </div>
    </div>
  );
};

export default MarketDashboard;
