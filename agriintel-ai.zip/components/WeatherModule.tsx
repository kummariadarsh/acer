
import React, { useState, useEffect } from 'react';
import { Cloud, Sun, CloudRain, Wind, Thermometer, Droplets, MapPin, Search, Loader2 } from 'lucide-react';
import { geminiService } from '../services/geminiService';

const WeatherModule: React.FC = () => {
  const [location, setLocation] = useState('Central Farmlands');
  const [isLoading, setIsLoading] = useState(false);
  const [weatherAI, setWeatherAI] = useState<string | null>(null);

  const getAgriWeather = async () => {
    setIsLoading(true);
    try {
      const prompt = `Provide an agricultural weather forecast for ${location}. 
      Include current conditions, a 3-day outlook, and specific advice for farmers (irrigation needs, spraying windows, frost risks).
      Use Google Search for real current weather data.`;
      const res = await geminiService.queryAgriculturalExpert(prompt, undefined, true);
      setWeatherAI(res.text);
    } catch (err) {
      console.error(err);
      setWeatherAI("Could not retrieve live weather data. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    getAgriWeather();
  }, []);

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-[2.5rem] p-8 text-white relative overflow-hidden shadow-2xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 opacity-80">
              <MapPin size={16} />
              <span className="text-sm font-medium tracking-wide uppercase">Your Micro-climate</span>
            </div>
            <div className="flex items-center gap-4">
              <h3 className="text-4xl font-bold">{location}</h3>
              <button 
                onClick={() => {
                  const newLoc = prompt("Enter location:");
                  if(newLoc) { setLocation(newLoc); getAgriWeather(); }
                }}
                className="p-2 bg-white/20 hover:bg-white/30 rounded-xl backdrop-blur transition-all"
              >
                <Search size={18} />
              </button>
            </div>
          </div>

          <div className="flex items-center gap-8">
            <div className="text-center">
              <div className="flex items-center justify-center mb-1 text-blue-200">
                <Thermometer size={20} />
              </div>
              <div className="text-2xl font-bold">24°C</div>
              <div className="text-[10px] uppercase font-bold opacity-60">Temp</div>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center mb-1 text-blue-200">
                <Droplets size={20} />
              </div>
              <div className="text-2xl font-bold">65%</div>
              <div className="text-[10px] uppercase font-bold opacity-60">Humidity</div>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center mb-1 text-blue-200">
                <Wind size={20} />
              </div>
              <div className="text-2xl font-bold">12km/h</div>
              <div className="text-[10px] uppercase font-bold opacity-60">Wind</div>
            </div>
          </div>
        </div>

        {/* Decorative elements */}
        <Sun className="absolute -top-10 -right-10 w-48 h-48 text-white/10" />
        <div className="absolute top-1/2 left-0 w-32 h-32 bg-white/10 rounded-full blur-3xl" />
      </div>

      <div className="bg-white rounded-3xl border border-slate-100 p-8 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <h4 className="text-lg font-bold text-slate-800 flex items-center gap-2">
            <CloudRain className="text-blue-500" /> Agri-Meteorological Insight
          </h4>
          <div className="flex items-center gap-2 px-3 py-1 bg-emerald-50 text-emerald-700 rounded-full text-xs font-bold border border-emerald-100">
            Live AI Data
          </div>
        </div>

        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-20 text-slate-400">
            <Loader2 className="w-10 h-10 animate-spin mb-4" />
            <p className="text-sm font-medium">Synthesizing local weather models...</p>
          </div>
        ) : (
          <div className="prose prose-slate max-w-none">
            <div className="whitespace-pre-wrap text-slate-600 leading-relaxed text-sm bg-slate-50 p-6 rounded-2xl border border-slate-100">
              {weatherAI}
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-6 bg-blue-50 border border-blue-100 rounded-2xl">
          <h5 className="font-bold text-blue-900 text-sm mb-2">Spraying Window</h5>
          <p className="text-xs text-blue-700">Winds are currently low. Ideal for pest control application until 2:00 PM today.</p>
        </div>
        <div className="p-6 bg-emerald-50 border border-emerald-100 rounded-2xl">
          <h5 className="font-bold text-emerald-900 text-sm mb-2">Irrigation Index</h5>
          <p className="text-xs text-emerald-700">Soil moisture evaporation is high. Increase irrigation cycle by 15% for maize crops.</p>
        </div>
        <div className="p-6 bg-amber-50 border border-amber-100 rounded-2xl">
          <h5 className="font-bold text-amber-900 text-sm mb-2">Harvest Forecast</h5>
          <p className="text-xs text-amber-700">Clear skies expected for next 4 days. Recommended window for soy harvesting.</p>
        </div>
      </div>
    </div>
  );
};

export default WeatherModule;
