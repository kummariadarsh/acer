
import React, { useState, useEffect } from 'react';
import { Layout, MessageCircle, Bug, TrendingUp, CloudSun, Menu, X, Send, Leaf, Search } from 'lucide-react';
import { View, Message } from './types';
import ChatInterface from './components/ChatInterface';
import DiagnosisModule from './components/DiagnosisModule';
import MarketDashboard from './components/MarketDashboard';
import WeatherModule from './components/WeatherModule';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<View>(View.CHAT);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const navItems = [
    { id: View.CHAT, label: 'Agri Query', icon: MessageCircle },
    { id: View.DIAGNOSIS, label: 'Pest Diagnosis', icon: Bug },
    { id: View.MARKET, label: 'Market Insights', icon: TrendingUp },
    { id: View.WEATHER, label: 'Agri Weather', icon: CloudSun },
  ];

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Sidebar - Desktop */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 w-64 bg-emerald-900 text-white transform transition-transform duration-300 ease-in-out
        lg:relative lg:translate-x-0 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="p-6 flex items-center gap-3">
          <div className="p-2 bg-emerald-500 rounded-lg">
            <Leaf className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-xl font-bold tracking-tight">AgriIntel AI</h1>
        </div>

        <nav className="mt-8 px-4 space-y-2">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setActiveView(item.id);
                setIsSidebarOpen(false);
              }}
              className={`
                w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all
                ${activeView === item.id 
                  ? 'bg-emerald-700 text-white shadow-lg shadow-emerald-950/20' 
                  : 'text-emerald-100 hover:bg-emerald-800'}
              `}
            >
              <item.icon className="w-5 h-5" />
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="absolute bottom-0 left-0 right-0 p-6">
          <div className="p-4 bg-emerald-800/50 rounded-2xl border border-emerald-700/50">
            <p className="text-xs text-emerald-300 uppercase tracking-widest font-semibold mb-1">System Status</p>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-sm font-medium">Gemini Pro Active</span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 bg-white lg:rounded-l-[2rem] shadow-2xl relative overflow-hidden">
        {/* Header */}
        <header className="h-16 flex items-center justify-between px-6 border-b border-slate-100 bg-white/80 backdrop-blur-md sticky top-0 z-40">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="lg:hidden p-2 hover:bg-slate-100 rounded-lg"
            >
              <Menu className="w-6 h-6 text-slate-600" />
            </button>
            <h2 className="text-lg font-semibold text-slate-800">
              {navItems.find(i => i.id === activeView)?.label}
            </h2>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-emerald-50 rounded-full border border-emerald-100">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span className="text-xs font-semibold text-emerald-700">Precision Farming</span>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8">
          {activeView === View.CHAT && <ChatInterface />}
          {activeView === View.DIAGNOSIS && <DiagnosisModule />}
          {activeView === View.MARKET && <MarketDashboard />}
          {activeView === View.WEATHER && <WeatherModule />}
        </div>
      </main>

      {/* Overlay for mobile sidebar */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}
    </div>
  );
};

export default App;
