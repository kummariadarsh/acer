
export enum View {
  CHAT = 'CHAT',
  DIAGNOSIS = 'DIAGNOSIS',
  MARKET = 'MARKET',
  WEATHER = 'WEATHER'
}

export interface Message {
  role: 'user' | 'model';
  content: string;
  image?: string;
  groundingUrls?: Array<{ title: string; uri: string }>;
  isStreaming?: boolean;
}

export interface MarketData {
  crop: string;
  price: number;
  change: number;
  trend: 'up' | 'down' | 'stable';
}

export interface DiagnosisResult {
  condition: string;
  severity: 'low' | 'medium' | 'high';
  recommendations: string[];
  confidence: number;
}
